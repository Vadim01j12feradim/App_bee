<?php

class Sesion{

    var $id_sesion;
    var $foto;
    var $latitude;
    var $longitud;
    var $descripcion;
    var $name;//name of user
    var $id;

    function insertar(){
        include_once("../settings/DBConnect.php");
        $conn = null;
        $stmt=  null;
        $nA = 0;
        $conn = new DBConnect(); // se construye el objeto
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect

        $query="insert into sesion(foto,latitude,longitud,descripcion,id) values('$this->foto','$this->latitude','$this->longitud','$this->descripcion','$this->id') ";
        $stmt = $conexion->prepare($query);
        $nA = $stmt->execute();
       
        return $nA;

    }
    function sessionsAllUsers(){
        include_once("../settings/DBConnect.php");
        $conn = null;
        
        $stmt=  null;
        $conn = new DBConnect(); // se construye el objeto
        
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
       
        include_once("../models/Usuario.php");
        
        
    }
    function listarTodos($one){
        include_once("../settings/DBConnect.php");
        $conn = null;
        
        $stmt=  null;
        $conn = new DBConnect(); // se construye el objeto
        
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
       
        include_once("../models/Usuario.php");
        
        $us = new Usuario();
       
        $us->username = $this->id;
        
        $this->id = $us->getIDbyUsername();
        
        $query="SELECT * FROM sesion where id = ".$this->id;
        if($one)
            $query="SELECT * FROM sesion where id_sesion = ".$this->id_sesion;
        $stmt = $conexion->prepare($query);
        
        $stmt->execute();
        $i=0;
        
        while($dato = $stmt->fetch(PDO::FETCH_ASSOC)){
            $cat = new Sesion();
            $cat->id_sesion = $dato["id_sesion"];
            $cat->foto= $dato["foto"];
            $cat->latitude = $dato["latitude"];
            $cat->longitud = $dato["longitud"];
            $cat->descripcion = $dato["descripcion"];
            $cat->id = $dato["id"];
            $cat->name = $us->username;
            if($one)
                return $cat;
            $arrCategorias[$i] = $cat;
            $i = $i +1;

        }
        return $arrCategorias;
    }
    function _getByDate(){
        include_once("../settings/DBConnect.php");
        $conn = null;
        
        $stmt=  null;
        $conn = new DBConnect(); // se construye el objeto
        
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
       
        include_once("../models/Usuario.php");
        
        $us = new Usuario();
       
        $us->username = $this->id;
        
        $this->id = $us->getIDbyUsername();
        
        $query="SELECT sesion.id_sesion, sesion.foto, sesion.latitude, sesion.longitud, sesion.descripcion,
            sesion.id,toma.id_toma, toma.audio, toma.fecha, toma.id_metodo,usuario.username FROM sesion
            JOIN toma ON sesion.id_sesion = toma.id_sesion
            JOIN usuario ON sesion.id = usuario.id
            WHERE toma.fecha >= STR_TO_DATE('".$this->longitud."','%d/%m/%Y') AND toma.fecha <= STR_TO_DATE('".$this->latitude."','%d/%m/%Y')";
        
        if($this->descripcion == 0)
            $query=$query." AND usuario.id = '".$this->id."'";
        $query=$query." ORDER BY toma.fecha ASC;";
        //return $query;
        $stmt = $conexion->prepare($query);
        $stmt->execute();
        $i=0;
        $arrCategorias = [];
        while($dato = $stmt->fetch(PDO::FETCH_ASSOC)){
            $cat->id_sesion = $dato["id_sesion"];
            $cat->foto= $dato["foto"];
            $cat->latitude = $dato["latitude"];
            $cat->longitud = $dato["longitud"];
            $cat->descripcion = $dato["descripcion"];
            $cat->id = $dato["id"];
            $cat->name = $us->username;
            
            $arrCategorias[$i] = array('id_sesion'=>$dato["id_sesion"],'foto'=>$dato["foto"],'latitude'=>$dato["latitude"],'longitud'=>$dato["longitud"],
            'descripcion'=>$dato["descripcion"],'id'=>$dato["id"],'id_toma'=>$dato["id_toma"],'audio'=>$dato["audio"],'fecha'=>$dato["fecha"],'id_metodo'=>$dato["id_metodo"],'username'=>$dato["username"]);
            $i = $i +1;
        }
        return $arrCategorias;
        
        
        
        
         
        
    }

    function login(){
        include_once("../settings/DBConnect.php");
        $conn = null;
        $stmt=  null;
        $conn = new DBConnect(); // se construye el objeto
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
        $arrCategorias=null;
        $query="SELECT * FROM usuario where usuario='$this->usuario' and pwd='$this->pwd'";
        $stmt = $conexion->prepare($query);
        $stmt->execute();
        $log=false;
        while($dato = $stmt->fetch(PDO::FETCH_ASSOC)){
            $this->id = $dato["id"];
            $this->nombre = $dato["nombre"];
            $this->last_name = $dato["last_name"];
            $this->sur_name = $dato["sur_name"];
            $this->username = $dato["username"];
            $this->pwd = $dato["pwd"];
            $this->tipo = $dato["tipo"];
            $log=true;
            
        }
        return $log;
    }
}

?>