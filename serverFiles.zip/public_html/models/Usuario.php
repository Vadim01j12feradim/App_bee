<?php

class Usuario{

    var $id;
    var $nombre;
    var $last_name;
    var $sur_name;
    var $username;
    var $pwd;
    var $tipo;

    function insertar(){
        include_once("../settings/DBConnect.php");
        $conn = null;
        $stmt=  null;
        $nA = 0;
        $conn = new DBConnect(); // se construye el objeto
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
        //return $this.buscar();
        //if(!$this.buscar()){
        $query="insert into usuario(nombre,last_name,sur_name,username,pwd,tipo) values('$this->nombre','$this->last_name','$this->sur_name','$this->username','$this->pwd','$this->tipo') ";
        $stmt = $conexion->prepare($query);
        $nA = $stmt->execute();
        return $nA;
        //}
    }

    function changePassword(){//Function for login
        try{
            include_once("../settings/DBConnect.php");
            $conn = null;
            $stmt=  null;
            $conn = new DBConnect(); // se construye el objeto
            $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
            $arrCategorias=null;
            
            $stmt = $conexion->prepare('UPDATE usuario SET pwd = :pwd WHERE username = :username');
    
            // 3. Bind the parameter values to the placeholders
            $stmt->bindParam(':pwd', $pwd);
            $stmt->bindParam(':username', $username);
            
            // 4. Set the parameter values
            $pwd = $this->pwd;
            $username = $this->username;
            
            // 5. Execute the statement
            $stmt->execute();
            
            return "The password has actualized";
            }
            catch (PDOException $e) {
                return 'An error ocurred: ' . $e->getMessage();
            }
        
        
    }

    function listarTodos(){
        include_once("../settings/DBConnect.php");
        $conn = null;
        $stmt=  null;
        $conn = new DBConnect(); // se construye el objeto
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
        $arrCategorias=null;
        $query="SELECT * FROM usuario";
        $stmt = $conexion->prepare($query);
 

        $stmt->execute();
        $i=0;
        while($dato = $stmt->fetch(PDO::FETCH_ASSOC)){
            $cat = new Usuario();
            $cat->id = $dato["id"];
            $cat->nombre = $dato["nombre"];
            $cat->last_name = $dato["last_name"];
            $cat->sur_name = $dato["sur_name"];
            $cat->username = $dato["username"];
            $cat->pwd = $dato["pwd"];
            $cat->tipo = $dato["tipo"];
            $arrCategorias[$i] = $cat;
            $i = $i +1;

        }
        return $arrCategorias;
    }

    function getIDbyUsername(){
        include_once("../settings/DBConnect.php");
        $conn = null;
        $stmt=  null;
        $conn = new DBConnect(); // se construye el objeto
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
        $arrCategorias=null;
        $stmt = $conexion->prepare("SELECT id FROM usuario where username=?");
        
        $stmt->bindParam(1, $this->username);
        $stmt->execute();
        $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($resultados as $dato) {
                return $dato["id"];;
            }
        return null;
    }
    function buscar(){
        include_once("../settings/DBConnect.php");
        $conn = null;
        $stmt=  null;
        $conn = new DBConnect(); // se construye el objeto
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
        $arrCategorias=null;
        $stmt = $conexion->prepare("SELECT * FROM usuario where username=?");
        
        $stmt->bindParam(1, $this->username);
       
        $stmt->execute();
        if ($stmt->rowCount() > 0) {
            $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($resultados as $dato) {
                $this->id = $dato["id"];
                $this->nombre = $dato["nombre"];
                $this->last_name = $dato["last_name"];
                $this->sur_name = $dato["sur_name"];
                $this->username = $dato["username"];
                $this->pwd = $dato["pwd"];
                $this->tipo = $dato["tipo"];
                return true;
            }
            
        }else{
             return false;
        }
    }

    function login(){
        include_once("../settings/DBConnect.php");
        $conn = null;
        $stmt=  null;
        //return 34;
        $conn = new DBConnect(); // se construye el objeto
        
        $conexion = $conn->connect(); //el objeto invoca mediante una flecha -> a la funcion connect escrita en DBConnect
        
        $arrCategorias=null;
        $stmt=$conexion->prepare("SELECT * FROM usuario where username=? and pwd=?");
        
        
        $stmt->bindParam(1, $this->username);
        $stmt->bindParam(2, $this->pwd);
        $stmt->execute();
        if ($stmt->rowCount() > 0) {
            $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($resultados as $dato) {
                $this->id = $dato["id"];
                $this->nombre = $dato["nombre"];
                $this->last_name = $dato["last_name"];
                $this->sur_name = $dato["sur_name"];
                $this->username = $dato["username"];
                $this->pwd = $dato["pwd"];
                $this->tipo = $dato["tipo"];
                return $this;
            }
            
        } else {
            return false;
        }
    }
}

?>