<?php
define('DB_USERNAME', 'id20472336_root');
define('DB_PASSWORD', 'P@ssword123Bee');
define('DB_HOST', 'localhost');
define('DB_NAME', 'id20472336_bee_app');
?>