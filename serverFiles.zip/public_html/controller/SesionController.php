<?php 



 

$request_body = file_get_contents('php://input');
$data = json_decode($request_body, true);
$target_dir = "./sesionphotos/";


$target_file = $target_dir . basename($_FILES["photo"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
$check = getimagesize($_FILES["photo"]["tmp_name"]);
  if($check !== false) {
   // echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    //echo "File is not an image.";
    $uploadOk = 0;
  }
  
  if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
    //echo "ok from the server ";
    
    include_once("../models/Usuario.php");
    include_once("../models/Sesion.php");
    $usuario =new Usuario();
    
    $sesion= new Sesion();
    $usuario->username=$_POST["username"];
    
    if($usuario->buscar()){
         $sesion->foto=basename($_FILES["photo"]["name"]);
         $sesion->id = $usuario->id;
         
         $sesion->name = $_POST["name"];
         
         $sesion->descripcion = $_POST["observations"];
       
         /*  
         if (file_exists($target_file)) {
             echo "El archivo existe";
         }else{
             echo"El archivo no existe";
         }*/
         
         
         $sesion->latitude = "Undefined";
         $sesion->longitud = "Undefined";
         
         $exif = exif_read_data($target_file, 0, true);

        if (!empty($exif['GPS'])) {
          $latitude = getGps($exif['GPS']['GPSLatitude'], $exif['GPS']['GPSLatitudeRef']);
          $longitude = getGps($exif['GPS']['GPSLongitude'], $exif['GPS']['GPSLongitudeRef']);
          $sesion->latitude = $latitude;
          $sesion->longitud = $longitude;
          //echo "La ubicación de la imagen es: latitud $latitude, longitud $longitude";
        } else {
          //echo "No se ha encontrado información de ubicación en la imagen.";
        }
         echo "Direccion ".$target_file;
         echo $sesion->insertar();
    }
  }
  
//***************************** GPS ****************************
function getGps($exifCoord, $hemi) {
  $degrees = count($exifCoord) > 0 ? gps2Num($exifCoord[0]) : 0;
  $minutes = count($exifCoord) > 1 ? gps2Num($exifCoord[1]) : 0;
  $seconds = count($exifCoord) > 2 ? gps2Num($exifCoord[2]) : 0;
  
  $flip = ($hemi == 'W' || $hemi == 'S') ? -1 : 1;
  
  return $flip * ($degrees + $minutes / 60 + $seconds / 3600);
}

function gps2Num($coordPart) {
  $parts = explode('/', $coordPart);
  if (count($parts) <= 0) return 0;
  if (count($parts) == 1) return $parts[0];
  return floatval($parts[0]) / floatval($parts[1]);
}


//***********************************************************
?>