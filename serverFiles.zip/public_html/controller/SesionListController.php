<?php
include_once("../models/Sesion.php");
$ses = new Sesion();
$ses->id = $_POST['name'];//username

if (isset($_POST['id_sesion'])) {
  $ses->id_sesion = $_POST['id_sesion'];
  echo json_encode($ses->listarTodos(true));
} else {
    if(isset($_POST['option'])){
            //username is id
            $ses->longitud = $_POST['min'];//max date
            $ses->latitude = $_POST['max'];//min date
            $ses->descripcion = $_POST['option']; //one or all
            echo json_encode($ses->_getByDate());
    }else
        echo json_encode($ses->listarTodos(false));
  
}

?>