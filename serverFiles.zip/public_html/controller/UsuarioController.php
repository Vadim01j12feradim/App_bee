<?php 

 
/*
$request_body = file_get_contents('php://input');
$data = json_decode($request_body, true);
*/
$OPC = $_POST['OPC'];
//echo json_encode($OPC);
if(!empty($OPC)){
    //Login to user
    switch($OPC){
        case 1://insert new user
            //Add user
            include_once("../models/Usuario.php");
            $usu = new Usuario();
            $usu->username = $_POST['txtUsername'];
            $usu->pwd = $_POST['txtPwd'];
            $usu->last_name = $_POST['txtLastName'];
            $usu->sur_name = $_POST['txtSurName'];
            $usu->nombre = $_POST['txtName'];
            $usu->tipo = 0;
            echo json_encode($usu->insertar());
            break;
            
        case 2://login new user
            $txtUsername = $_POST['txtUsername'];
            $txtPwd = $_POST['txtPwd'];
            include_once("../models/Usuario.php");
            $usu = new Usuario();
            $usu->username = $txtUsername;
            $usu->pwd = $txtPwd;
            //echo $usu->username.":".$usu->pwd;
            echo json_encode($usu->login());
            break;
        case 3://change passworg for user
            $txtUsername = $_POST['txtUsername'];
            $txtPwd = $_POST['txtPwd'];
            include_once("../models/Usuario.php");
            $usu = new Usuario();
            $usu->username = $txtUsername;
            $usu->pwd = $txtPwd;
            
            echo json_encode($usu->changePassword());
            break;
        default:
            echo "Invalid QUERY";
            break;
    }
}

/*
if(isset($_GET["LST"])){

    //Listar proveedores
    if($_GET["LST"] == 1){
        include_once("../Models/Proveedor.php");
        $cat = new Proveedor();
         
        $resultado = $cat->listarTodos();
        echo json_encode($resultado);

    }
}
*/
?>